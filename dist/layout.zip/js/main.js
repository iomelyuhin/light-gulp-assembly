document.addEventListener(`DOMContentLoaded`, function () {

	console.log("main.js is running")

})